import React from "react";

export default function BalticCountries() {
  return (
    <ul className="BalticCountries">
      <li>🇱🇹 Lithuania</li>
      <li>🇪🇪 Estonia</li>
      <li>🇱🇻 Latvia</li>
    </ul>
  );
}
